from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:38632/AAC' % (username, password))
        self.database = self.client['AAC']

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

    # Create method to implement the R in CRUD.
    def read(self, data):
        if data is not None:
            animal = self.database.animals.find(data, {"_id":False}) # data should be dictionary
        else:
            animal = self.database.animals.find({"_id":False})
        return animal

    # Create method to implement the U in CRUD.
    def update(self, data, update):
        if data is not None:
            self.database.animals.update_one(data, update)  # data should be KVP, update should be KVP({set:{update}})
            if self.database.animals.find(update) != None:  # if we can find the update KVP
                return self.database.animals.find(update)  # we return it in JSON format
            else:
                raise Exception("Error the updated record could not be found in the database.")  # otherwise we return an error
        else:
            raise Exception("Nothing to update, because data parameter is empty")
  
    # Create method to implement the D in CRUD.
    def delete(self, data):
        if data is not None:
            self.database.animals.delete_one(data)  # data should be dictionary
            if self.database.animals.find(data) is None:  # if find returns something, we didn't successfully delete it
                return "Successfully deleted record"  # otherwise return a success message               
        else:
            raise Exception("There is no argument for data, enter KVP of item you want to delete and try again.")
            
    def count(self, data = None):
        animal_count = self.database.animals.count(data)
        return animal_count